const db = require('./db');
const User = require('./models/user');
//
const user = new User({
    name: 'John DOE',
    email: 'test@test.com',
    birth: new Date(1990, 7, 20),
    password: 'testtest'
});
//
user.save(function (err, user) {
    if (err || !user)
        return;
    //
    console.log(
        'Connect with:\nEmail: %s\nPassword: %s',
        user.email,
        user.password
    );
});
//