// for
// type
// description
const mongoose = require('mongoose');
//
const notificationSchema = mongoose.Schema({
    destination: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    description: String,
    status: Boolean
});
const Notification = mongoose.model('Notification', notificationSchema);
//
module.exports = Notification;