const mongoose   = require('mongoose');
//
// lastConnection, isConnected
// fullName, hashedPassword, birthDate
// classEnrollments
//
const userSchema = mongoose.Schema({
    name: {
        type:     String,
        required: true
    },
    email: {
        type:     String,
        trim:     true,
        unique:   true,
        required: true
    },
    password: {
        type:      String,
        minlength: [8, "Password can't have less than 8 characters"],
        required:  true
    },
    birth: {
        type:     Date,
        required: true
    },
    following: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }]
});
const User = mongoose.model('User', userSchema);
//
module.exports = User;