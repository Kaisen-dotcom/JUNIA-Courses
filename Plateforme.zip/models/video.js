const mongoose = require('mongoose');
//
const videoSchema = mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    title: {
        type: String,
        required: true
    },
    video: {
        type: String,
        required: true
    },
    question: [{
        questionTime: Number,
        questionText: String
    }],
    answer: [{
        questionId: mongoose.Schema.Types.ObjectId,
        answerText: String,
        answerPoint: Number
    }]
});
const Video = mongoose.model('Video', videoSchema);
//
module.exports = Video;