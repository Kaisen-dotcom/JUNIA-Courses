const mongoose = require('mongoose');
//
const messageSchema = mongoose.Schema({
    source: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    roomId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Room',
        required: true
    },
    date: {
        type: Date,
        default: Date.now()
    },
    message: String
});
const Message = mongoose.model('Message', messageSchema);
//
module.exports = Message;