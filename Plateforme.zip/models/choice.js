const mongoose = require('mongoose');
//
const choiceSchema = mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    question: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Video.question'
    },
    score: Number
});
choiceSchema.index({ user: 1, question: 1 }, { unique: true });
const Choice = mongoose.model('Choice', choiceSchema);
//
module.exports = Choice;