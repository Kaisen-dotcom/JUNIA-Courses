const mongoose = require('mongoose');
//
const roomSchema = mongoose.Schema({
    name: String,
    members: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    }],
    lastTime: Date
});
const Room = mongoose.model('Room', roomSchema);
//
module.exports = Room;