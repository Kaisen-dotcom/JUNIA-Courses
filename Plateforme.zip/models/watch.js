const mongoose = require('mongoose');
//
const watchSchema = mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        unique: true,
        required: true
    },
    video: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Video',
        required: true
    },
    watchtime: {
        type: Number,
        default: 0
    }
});
const Watch = mongoose.model('Watch', watchSchema);
//
module.exports = Watch;