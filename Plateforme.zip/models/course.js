const mongoose = require('mongoose');
//
const courseSchema = mongoose.Schema({
    author: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    title: {
        type: String,
        required: true
    },
    level: {
        type: Number,
        min: 0,
        max: 4
    },
    //
    description: String,
    category: String,
    image: String,
    public: Boolean,
    //
    participants: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }]
});
const Course = mongoose.model('Course', courseSchema);
//
module.exports = Course;