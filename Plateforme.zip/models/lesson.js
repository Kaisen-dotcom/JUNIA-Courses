const mongoose = require('mongoose'),
      jsdom = require('jsdom'),
      katex = require('katex'),
      markit = require('markdown-it'),
      texmath = require('markdown-it-texmath'),
      purifier = require('dompurify');
//
const tm = texmath.use(katex),
      md = markit({ html: true }).use(tm, {delimiters: 'dollars'}),
      window = new jsdom.JSDOM('').window,
      purify = purifier(window);
//
const lessonSchema = mongoose.Schema({
    author: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    markdown: String,
    transformedHtml: String,
    course: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Course',
        required: true
    },
    video: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Video'
    }},
    { timestamps: true }
);
//
lessonSchema.pre('validate', function (next)
{
    //
	this.markdown = this.markdown ? this.markdown : '';
    this.transformedHtml = purify.sanitize(md.render(this.markdown));
    next();
});
//
const Lesson = mongoose.model('Lesson', lessonSchema);
module.exports = Lesson;
