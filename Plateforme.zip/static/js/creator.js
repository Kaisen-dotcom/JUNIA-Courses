/*
    https://developer.mozilla.org/en-US/docs/Web/API/CustomEvent/CustomEvent
    https://developer.mozilla.org/en-US/docs/Web/API/FormData/Using_FormData_Objects
*/
const player = document.querySelector('video'),
      table  = document.querySelector('tbody'),
      form   = document.querySelector('form'),
      list   = document.getElementById('answerList'),
      all    = new Array(),
      createButton = document.getElementById('createButton');
//
var   currentQuestion;
const parent = window.opener;
if (! parent) history.back();
//
const notifyUpload = (detail) =>
{
    const uploadEvent = new CustomEvent('upload', { detail });;
    parent.dispatchEvent(uploadEvent);
};
//
function createHandler(event)
{
    event.preventDefault();
    createButton.disabled = true;
    //
    fetch('/video/create',
    {
        method: form.method,
        body: new FormData(form)
    })
    .then(response  => response.json())
    .then(videoData => notifyUpload(videoData))
    .catch(error => console.log(error));
}
//
createButton.addEventListener('click', createHandler);
//
function handleFile(video)
{
    const file = video.files[0];
    if (! file)
        return;
    //
    player.src = URL.createObjectURL(file);
}
//
$(document).on('click', '.time', function ()
{
    const savedTime = this.children[0];
    if (! player.src)
        return;
    //
    savedTime.value = Math.round(player.currentTime);
});
//
$(document).on('click', '#addButton', function (event)
{
    event.preventDefault();
    //
    const questionTr = document.createElement('tr'),
          questionTd = document.createElement('td'),
          choiceTd   = document.createElement('td'),
          choiceDiv  = document.createElement('div'),
          innerDiv   = document.createElement('div'),
          questionIn = document.createElement('input'),
          choiceIn   = document.createElement('input');
    //
    questionIn.className = 'form-control';
    choiceIn.className   = 'form-control';
    choiceDiv.className  = 'd-inline-block position-relative time';
    innerDiv.className   = 'position-absolute top-0 bottom-0 start-0 end-0';
    //
    questionIn.setAttribute('type', 'text');
    choiceIn.setAttribute  ('type', 'number');
    questionIn.setAttribute('name', 'questionText[]');
    choiceIn.setAttribute  ('name', 'questionTime[]');
    choiceIn.setAttribute  ('value', 0);
    //
    questionTd.appendChild(questionIn);
    choiceTd.appendChild(choiceDiv);
    choiceDiv.appendChild(choiceIn);
    choiceDiv.appendChild(innerDiv);
    questionTr.appendChild(choiceTd);
    questionTr.appendChild(questionTd);
    table.appendChild(questionTr);
    questionTr.setAttribute('data-id', all.length);
    questionTr.addEventListener('click', questionClick);
    //
    const anData = new Array();
    anData.push(createAnswer());
    anData.push(createAnswer());
    anData.push(createAnswer());
    anData.push(createAnswer());
    all.push(anData);
    list.append(...anData);
    //
    highlightQuestion(questionTr, all.length - 1);
});
//
function createAnswer()
{
    //
    const rowDiv = document.createElement('div'),
          c1Div = document.createElement('div')
          c2Div = document.createElement('div'),
          answerIn = document.createElement('input'),
          pointIn = document.createElement('input');
    //
    rowDiv.className   = 'row g-1 p-1';
    c1Div.className    = 'col-md-9';
    c2Div.className    = 'col-md-3';
    answerIn.className = 'form-control';
    pointIn.className  = 'form-control'; 
    //
    answerIn.setAttribute('type', 'text');
    answerIn.setAttribute('name', 'answerText[]');
    answerIn.setAttribute('placeholder', 'Answer');
    pointIn.setAttribute('type', 'number');
    pointIn.setAttribute('name', 'answerPoint[]');
    pointIn.setAttribute('value', '-1');
    pointIn.setAttribute('step', '0.1');
    pointIn.setAttribute('placeholder', 'Points');
    //
    c1Div.appendChild(answerIn);
    c2Div.appendChild(pointIn);
    rowDiv.appendChild(c2Div);
    rowDiv.appendChild(c1Div);
    //
    return rowDiv;
}
//
function questionClick(event)
{
    const target = event.currentTarget;
    const id = target.getAttribute('data-id');
    //
    highlightQuestion(target, id);
}
//
function highlightQuestion(node, id)
{
    const parent   = node.parentNode;
    const siblings = Array.from(parent.children);
    const current  = Array.from(list.children);
    //
    siblings.forEach(node => node.style.backgroundColor = '');
    node.style.backgroundColor = 'lightgray';
    current.forEach(node => node.style.display = 'none');
    all[id].forEach(node => node.style.display = '');
    //
    currentQuestion = node;
}
//
function removeQuestion()
{
    if (! currentQuestion)
        return;
    //
    var node = currentQuestion;
    var   id = node.getAttribute('data-id');
    //
    node.style.backgroundColor = 'red';
    all[id].forEach(node => list.removeChild(node));
    all.splice(id, 1);
    //
    while ((node = node.nextSibling))
        node.setAttribute('data-id', id++);
    table.removeChild(currentQuestion);
    currentQuestion = null;
}
//
$(document).on('keyup', function (event)
{
    if ( event.keyCode != 46 ||
       ! currentQuestion     ||
       ! confirm('Delete this question?'))
        return;
    //
    removeQuestion(currentQuestion);
});