var courseId,
    courseTitle,
    courseLink;
//
courseLink = document.getElementById('courseLink');
//
function createCard(
    courseId,
    courseImage,
    courseTitle,
    courseCategory,
    courseDifficulty,
    authorImage,
    authorName
)
{
    ///
    const colorArray = [
        '#05c46b',
        '#ffc048',
        '#ffa801',
        '#ff3f34',
        '#eb2f06'
    ];
    //
    const caption = [
        'Easy',
        'Normal',
        'Medium',
        'Difficult',
        'Challenging'
    ];
    //
    const cCard  = document.createElement('span'),
          cImage = document.createElement('img'),
          cDetail= document.createElement('span'),
          cDesc  = document.createElement('span'),
          cTitle = document.createElement('span'),
          cCat   = document.createElement('span'),
          cDiff  = document.createElement('span'),
          cDiffIn= document.createElement('i'),
          cSep   = document.createElement('div'),
          cFooter= document.createElement('span'),
          aImage = document.createElement('img'),
          aName  = document.createElement('span'),
          popUp  = document.createElement('span');
    //
    cCard.classList.add('ccard');
    cImage.classList.add('ccard-header');
    cDetail.classList.add('ccard-detail');
    cDesc.classList.add('ccard-description');
    cTitle.classList.add('ccard-title');
    cDiff.classList.add('ccard-difficulty');
    cSep.classList.add('ccard-separator');
    cFooter.classList.add('ccard-footer');
    aImage.classList.add('author-image');
    aName.classList.add('author-name', 'mx-2');
    popUp.classList.add('ccard-popup');
    //
    cDiffIn.classList.add('bi', 'bi-reception-' + courseDifficulty);
    cDiffIn.setAttribute('title', caption[courseDifficulty]);
    cDiffIn.style.color = colorArray[courseDifficulty];
    //
    cImage.src = courseImage;
    aImage.src = authorImage;
    //
    cTitle.innerText = courseTitle;
    cCat.innerText   = courseCategory;
    aName.innerText  = authorName;
    popUp.innerText  = 'Open';
    //
    cDiff.appendChild(cDiffIn);
    cDesc.appendChild(cTitle);
    cDesc.appendChild(cCat);
    //
    cDetail.appendChild(cDesc);
    cDetail.appendChild(cDiff);
    // cFooter.appendChild(aImage);
    cFooter.appendChild(aName);
    //
    cCard.appendChild(cImage);
    cCard.appendChild(cDetail);
    cCard.appendChild(cSep);
    cCard.appendChild(cFooter);
    cCard.appendChild(popUp);
    //
    cCard.setAttribute('data-id', courseId);
    cCard.setAttribute('data-bs-toggle', 'offcanvas');
    cCard.setAttribute('data-bs-target', '#offcanvas');
    cCard.setAttribute('aria-controls', 'offcanvas'); 
    return cCard;
}
//
function updateList(courses)
{
    const Container     = document.getElementById('courseList');
    Container.innerText = '';
    //
    courses.forEach((course) =>
    {
        Container.appendChild(createCard(
            course._id,
            course.image,
            course.title,
            course.category,
            course.level,
            null,
            (course.author != null) ? (course.author).name : '?'));
        /*
        const courseDiv   = document.createElement('div'),
              courseBody  = document.createElement('div'),
              courseTitle = document.createElement('h5'),
              courseCat   = document.createElement('h6'),
              courseLink  = document.createElement('a');
        //
        courseDiv.className    = 'card shadow';
        courseBody.className   = 'card-body';
        courseLink.className   = 'btn-course stretched-link';
        courseTitle.className  = 'card-title fw-light';
        courseCat.className    = 'card-subtitle mb-12 text-muted';
        //
        courseTitle.innerText = course.title;
        courseCat.innerText   = course.category;
        courseLink.setAttribute('data-id', course._id);
        courseLink.setAttribute('data-bs-toggle', 'offcanvas');
        courseLink.setAttribute('data-bs-target', '#offcanvas');
        courseLink.setAttribute('aria-controls', 'offcanvas');  
        //
        courseBody.append(courseTitle,
                          courseCat,
                          courseLink);
        courseDiv.appendChild(courseBody);
        //
        Container.appendChild(courseDiv);
        */
    });
}
//
$(document).on('input', '#search', async function (event)
{
    const target  = event.target;
    const form    = target.closest('form');
    const courses = await fetch(form.action,
    {
        method: form.method,
        body: new URLSearchParams(new FormData(form))
    })
    .then((response) => response.json());
    //
    updateList(courses);
});
//
$(window).on('load', async function ()
{
    $('#search').trigger('input');
    //
    var popover = new bootstrap.Popover(document.getElementById('notificationBell'), {
        html: true,
        container: 'body',
        content: function () {
            return $('#notificationContent').html();
        }
    });
});
//
$(document).on('click', '.ccard', async function(event)
{
    const cardObject = event.currentTarget;
    courseId = cardObject.getAttribute('data-id');
    courseLink.setAttribute('href', `/view/${courseId}`);
    //
    const course   = await fetch(`/course/${courseId}`)
                    .then((response) => response.json());
    //
    document
    .getElementById('courseLabel')
    .innerText  = course.title;
    courseTitle = course.title;
    //
    document
    .getElementById('courseImage')
    .setAttribute('src', course.image);
    //
    document
    .getElementById('courseDescription')
    .innerText = course.description;
});
//
async function enrollUser()
{
    await fetch(`/enroll/${courseId}`);
    //
    document
    .getElementById('modalBody')
    .innerText = `You're now enrolled in ${courseTitle}.`;
    $('#modalEnroll').modal('toggle');
}
//