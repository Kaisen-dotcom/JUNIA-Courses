var popup = null,
    closeButton = null;
//
const remove = () => popup.classList.remove('visible');
function clickHandler(event)
{
    event.stopPropagation();
    popup.classList.toggle('visible');
};
window.addEventListener('click', remove);
//
window.addEventListener('load', function () {
    const profile = document.querySelector('.header-last');
    if (! profile)
        return;
    popup = document.querySelector('.header-last > div');
    closeButton = document.querySelector('.popup-close');
    //
    profile.addEventListener('click', clickHandler);
    popup.addEventListener('click',  event => event.stopPropagation());
    closeButton.firstChild.addEventListener('click', remove);
});