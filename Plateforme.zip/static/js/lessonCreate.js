var   targetTab = null;
const addButton = document.getElementById('add-video'),
      videoId   = document.getElementById('video-id');
//
const markdown = document.getElementById('rawContent'),
      // renderedContent = document.getElementById('renderedContent'),
      tm = texmath.use(katex),
      md = markdownit({ html: true }).use(tm, { delimiters: 'dollars' });
//
const handleUpload = (event) =>
{
    const params = Object.assign({}, event.detail);
    videoId.setAttribute('value', params.id);
    videoId.setAttribute('placeholder', params.title);
    addButton.classList.remove('d-block');
    addButton.hidden = true;
    videoId.hidden = false;
    //
    window.removeEventListener('upload', handleUpload);
    targetTab.close();
    targetTab = null;
};
const renderMarkdown = (v) => {
    markdown.value = v;
    return md.render(markdown.value);
}
//
if (addButton) {
    addButton.addEventListener('click', function () {
        targetTab = window.open(
            '/video/create',
            // '_blank'
            'popup',
            'width=1024, height=640'
        );
        //
        window.addEventListener('upload', handleUpload);
    });
}
//
// markdown.addEventListener('keyup', renderMarkdown);
// renderMarkdown();
//
const editor = new EasyMDE({
    element: document.getElementById('rawContent'),
    previewRender: renderMarkdown
});