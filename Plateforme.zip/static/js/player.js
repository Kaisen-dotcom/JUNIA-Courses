let   logLoop,
      questionData,
      questionList,
      answerData,
      answerList,
      answerValid,
      answerBad;
//
// https://katex.org/docs/autorender.html
const params = new Object();
params['throwOnError'] = false;
params['delimiters'] = [
    { left: '$$', right: '$$', display: true },
    { left: '$', right: '$', display: false },
    { left: '\\(', right: '\\)', display: false },
    { left: '\\[', right: '\\]', display: true }
];
//
let promise = Promise.resolve();  // Used to hold chain of typesetting calls
function typeset(code)
{
  promise = promise.then(() => MathJax.typesetPromise(code()))
                   .catch((err) => console.log('Typeset failed: ' + err.message));
  return promise;
}
//
const player   = document.querySelector('video'),
      question = document.querySelector('.question'),
      choices  = document.querySelector('.choices'),
      overlay  = document.querySelector('.overlay');
//
function logFunc()
{
    const playTime = Math.round(player.currentTime),
          videoUrl = window.location.href;
    //
    var   videoData   = Object();
    videoData['time'] = playTime;
    $.post(videoUrl, videoData);
    //
    if ((! questionList.length) ||
         playTime < questionList[0].questionTime)
         return;
    //
    questionData = questionList.shift();
    answerData = answerList.splice(0, 4);
    putQuestion(questionData.questionText, answerData);
}
//
player.addEventListener('play',  () => (logLoop = setInterval(logFunc, 1000)));
player.addEventListener('pause', () => clearInterval(logLoop));
//
$(window).load(function()
{
    var params;
    params = new URLSearchParams(window.location.search);
    //
    if (params.has('load'))
        player.currentTime = params.get('load');
    //
    var indexList;
    questionList = videoData.question;
    answerList   = videoData.answer;
    //
    indexList    = Array.from(questionList.keys());
    indexList.sort((i, j) => questionList[i].questionTime > questionList[j].questionTime);
    questionList = indexList.map(i => questionList[i]);
    answerList   = indexList.map(i => answerList.slice(i * 4, (i + 1) * 4));
    answerList   = [].concat(...answerList);
});
//
function putQuestion(questionText, answerAll)
{
    //
    const data = {
        question: questionText,
        choices: [
            answerAll[0].answerText,
            answerAll[1].answerText,
            answerAll[2].answerText,
            answerAll[3].answerText
    ]};
	//
    /* fetch(`/question/${questionId}`)
      .then((response) => response.json()); */
    //
    var   container,
          checkbox,
          label;
    //
    choices.innerHTML  = '';
    question.innerHTML = data.question;
    renderMathInElement(question, params);
    //
    data.choices.forEach(function (choice, index) {
		if (! choice.length) return;
		//
        const currentId = `choice${index}`;
        container = document.createElement('li');
        checkbox  = document.createElement('input');
        label     = document.createElement('label');
        //
        container.className = 'form-check d-flex align-items-center rounded p-1';
        checkbox.className  = 'form-check';
        label.className     = 'form-check-label mx-2 flex-fill list-group-item';
        //
        checkbox.setAttribute('id', currentId);
        checkbox.setAttribute('type', 'checkbox');
        checkbox.setAttribute('name', 'choice[]');
        checkbox.setAttribute('value', index);
        label.setAttribute('for', currentId);
        //
        label.innerHTML = choice;
        renderMathInElement(label, params);
        //
        container.appendChild(checkbox);
        container.appendChild(label);
        choices.appendChild(container);
    });
    //
    overlay.style['display'] = 'block';
    player.style['z-index']  = -1;
    player.pause();
    //
    answerValid = null;
    answerBad   = null;
}
//
$(document).on('submit', '#questionForm', async function (event)
{
    event.preventDefault();
    //
    let finalLink,
        answerCheck;
    //
    if (answerValid != null &&
        answerBad   != null)
        return verifyValid();
    //
    finalLink  = `/check/${videoData._id}/${questionData._id}?`;
    finalLink += $(this).serialize();
    //
    answerCheck = await fetch(finalLink)
    .then(response => response.json());
    answerValid = answerCheck[0].map(i => choices.children[i]);
    answerBad   = answerCheck[1].map(i => choices.children[i]);
    //
    for (i = 0; i < answerValid.length; i++) answerValid[i].style.backgroundColor = '#55efc4';
    for (i = 0; i < answerBad.length; i++)   answerBad[i].style.backgroundColor = '#d63031';
    //
    return verifyValid();
})
//
function verifyValid()
{
    let verified = true;
    for (i = 0; i < answerValid.length; i++) verified &= answerValid[i].children[0].checked;
    for (i = 0; i < answerBad.length; i++)   verified &= ! answerBad[i].children[0].checked;
    //
    if (! verified)
        return;
    //
    overlay.style['display'] = 'none';
    player.style['z-index']  = 0;
    player.play();
    //
    answerValid = null;
    answerBad   = null;
}