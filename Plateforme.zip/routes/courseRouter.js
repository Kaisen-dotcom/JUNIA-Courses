const path    = require('path'),
      multer  = require('multer-md5'),
      express = require('express'),
      courseController = require('../controllers/courseController');
//
const router  = express.Router();
const upload  = multer({
    dest: 'uploads/images/',
    fileFilter: function(_, file, callback)
    {
        const extension = path.extname(file.originalname);
        //
        if (! Array('.jpg', '.jpeg', '.png', '.gif')
            .includes(extension))
            return callback(null, false);
        callback(null, true);
    },
    limits:
    {
        fileSize: 8 * 1024 * 1024  // 8MB
    }
});
//
/*
    GET  /course/:courseId (View)
    POST /course/:courseId (Edit)
    GET  /enroll/:courseId
*/
router.post('/course/search', courseController.courseSearch);
router.route('/course/create')
      .get(courseController.courseForm)
      .post(upload.single('image'), courseController.courseCreate);
router.get('/course/:courseId', courseController.courseGetRaw);
router.route('/course/edit')
      .get(courseController.courseEditForm)
      .put(courseController.courseEdit);
router.get('/view/:courseId', courseController.courseGet);
router.get('/enroll/:courseId', courseController.courseEnroll);
// router.get('/courses', courseController.courseGetAll);
//
module.exports = router;