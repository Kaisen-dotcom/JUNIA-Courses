const express = require('express'),
      userController = require('../controllers/userController');
const router  = express.Router();

/*
    GET  /login
    POST /login
    GET  /dashboard
    GET  /profile (View)
    POST /profile (Edit)
    GET  /user/:userId
    GET  /logout
*/
/* router.route('/profile')
      .get()
      .post();
*/
router.post('/login',    userController.userLogin);
router.get('/dashboard', userController.userDashboard);         // MERGE WITH PROFILE
router.get('/logout',    userController.userLogout);
// router.get('/profile', userController.userProfile);
router.get('/profile/:userId',  userController.userProfile);
router.get('/notifications',    userController.userNotification);
router.route('/user/create')                                    // USER CREATION
      .get(userController.userForm)
      .post(userController.userCreate);
//
module.exports = router;