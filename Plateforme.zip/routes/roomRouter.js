const express = require('express'),
      roomController = require('../controllers/roomController');
const router  = express.Router();
//
router.get('/room/create', roomController.roomCreate);
//
module.exports = router;