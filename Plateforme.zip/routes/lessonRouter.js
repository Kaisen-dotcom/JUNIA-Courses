const express = require('express'),
      lessonController = require('../controllers/lessonController');
//
const router = express.Router();
//
router.route('/lesson/create')
      .get(lessonController.lessonForm)
      .post(lessonController.lessonCreate);
router.route('/lesson/edit')
      .get(lessonController.lessonEditForm)
      .put(lessonController.lessonEdit);
router.get('/lesson/:lessonId', lessonController.lessonGet);
router.delete('/lesson/delete', lessonController.lessonDelete);
router.get('/complete/:lessonId', lessonController.lessonComplete);
//
module.exports = router;