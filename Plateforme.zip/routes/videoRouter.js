const videoController = require('../controllers/videoController'),
      path    = require('path'),
      express = require('express'),
      multer  = require('multer-md5'),
      timeout = require('connect-timeout'), 
      router  = express.Router();
//
const upload  = multer({
      dest: 'uploads/videos/',
      fileFilter: function(_, file, callback)
      {
          const extension = path.extname(file.originalname);
          //
          if (extension != '.mp4')
              return callback(null, false);
          callback(null, true);
      },
      limits: {
            fileSize: 128 * 1024 * 1024    // 128MB
      }
});
//
router.route('/video/create')
      .get(videoController.createForm)
      .post(timeout('8m'), upload.single('video'), videoController.videoCreate);
router.route('/video/edit')
      .get(videoController.editForm);
//
router.get('/video/uploads', videoController.videoGetAll);
router.get('/video/restore', videoController.videoLast);
router.route('/video/:videoId')
      .get(videoController.videoGet)
      .post(videoController.videoSave);
router.route('/question/:questionId')
      .get(videoController.choiceGet);
router.delete('/video/delete', videoController.videoDelete);
router.get('/check/:videoId/:questionId', videoController.diffChoice);
//
module.exports = router;
