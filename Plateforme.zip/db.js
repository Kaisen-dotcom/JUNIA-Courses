const mongoose = require('mongoose');
const uri = 'mongodb://localhost:27017/exampleDB';
//
mongoose.connect(uri);
// .catch((err) => {throw err});
//
const Course = require('./models/course'),
      course = new Course({
        author:     '61c4c7758b659d8a6396d221',
        //
        image:      'security.jpg',
        title:      'Fundamentals of Cybersecurity',
        category:   'Science and Technology',
        description:'By 2023, the cybersecurity market is expected to grow to over 250 billion dollars. That makes it one of the fastest-growing and largest sectors in IT, globally.',
        //
        level:      1,
        public:     true
});
//