const path         = require('path'),
      express      = require('express'),
      jwt          = require('jsonwebtoken'),
      cookieParser = require('cookie-parser'),
      methodOverride = require('method-override'),
      app = express();
      
require('./db');
require('dotenv').config();
const userController = require('./controllers/userController'),
      userRouter     = require('./routes/userRouter'),
      courseRouter   = require('./routes/courseRouter'),
      lessonRouter   = require('./routes/lessonRouter'),
      videoRouter    = require('./routes/videoRouter'),
      roomRouter     = require('./routes/roomRouter');

app.use(methodOverride('_method'));
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'static')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// app.use('/css', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/css')));
app.use('/css', express.static(path.join(__dirname, 'node_modules/bootstrap-icons/font')));
// app.use('/js',  express.static(path.join(__dirname, 'node_modules/bootstrap/dist/js')));

app.use(function (request, response, next) {
    const {
        token
    } = request.cookies;
    //
    if (! token)
    {
        response.clearCookie('token');
        next();
        return;
    }
    //
    jwt.verify(token, process.env.SECRET_KEY, async (err, decoded) =>
    {
        if (err)
        {
            response.clearCookie('token');
            next();
            return;
        }
        //
        if (decoded.exp <= Date.now() / 1000)
        {
            response.clearCookie('token');
            next();
            return;
        }
        //
        response.locals.user = await userController.userGet(decoded.email);
        next();
    });
});

app.get('/', (_, response) => response.render('home'));
app.get('/create', (_, response) => response.render('create'));

app.use('/', userRouter);
app.use('/', courseRouter);
app.use('/', lessonRouter);
app.use('/', videoRouter);
app.use('/', roomRouter);

/* app.post('/login', (request, response) => {
    const user = users[request.body.email];

    if (user['password'] != request.body.password)
    {
        response
        .status(401)
        .send('Unauthorized');
        return;
    }

    response.cookie('token',
        jwt.sign({
            email: request.body.email,
        }, process.env.SECRET_KEY, {
            expiresIn: 60 * 1000
        }),
        {
            httpOnly: true,
            secure: true,
            maxAge: 60 * 1000
    })
    .redirect(302, '/');
});

app.get('/logout', function (request, response) {
    return response
    .clearCookie('token')
    .redirect(302, '/');
});*/

app.use(function (request, response) {
    response.redirect('/');
});

app.listen(3000, function () {
    console.log('Server listening on port 3000.');
});