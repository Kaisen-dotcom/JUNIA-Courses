const fs        = require('fs'),
      path      = require('path'),
      Video     = require('../models/video'),
      Watch     = require('../models/watch'),
      Choice    = require('../models/choice');
const Lesson = require('../models/lesson');
//
function videoGetAll(request, response, next)
{
    // Drop guest requests.
    const user = response.locals.user;
    if (! user)
        return next();
    // Look up videos that this
    // user uploaded and return
    // a JSON array.
    const filter   = new Object();
    filter['user'] = user._id;
    Video.find(filter, '_id title', (_, videos) => response.json(videos));
}
//
async function findChoice(userId, questionId)
{
    // Find if an individual already
    // responded to certain Question.
    return await Choice.findOne({ user: userId, question: questionId });
}
//
function videoGet(request, response, next)
{
    const  user    = response.locals.user;
    const  videoId = request.params.videoId;
    var    indexList,
           promList,
           tmpList;
    // Exclude sensitive information (correctness)
    // from being dumped with Projection.
    Video
    .findById(videoId, '-answer.answerPoint')
    .exec(async function (err, video) {
        if (err || !video)
            return next();
        //
        if (user)
        {
            // Exclude questions to which
            // the user already responded.
            indexList = Array.from((video.question).keys());
            promList  = indexList.map(i => findChoice(user._id, (video.question)[i]._id));
            promList  = await Promise.all(promList);
            indexList = indexList.filter((_, i) => promList[i] == null);
            // Reorder the resulting list before
            // sending it as a View parameter,
            // _id will be recalculated.
            (video.question) = indexList.map(i => (video.question)[i]);
            tmpList = indexList.map(i => (video.answer).slice(i * 4, (i + 1) * 4));
            tmpList = [].concat(...tmpList);
            for (i = 0; i < tmpList.length; i++) delete tmpList[i]._id;
            (video.answer) = tmpList;
        }
        //
        response.render(path.join('video', 'view.ejs'), { video });
    });
}
//
function videoLast(request, response, next)
{
    // No watch record is kept for
    // visitors, drop the request.
    const user = response.locals.user;
    if (! user)
        return next();
    //
    Watch.findOne(
        { user: user._id },
        [ 'video', 'watchtime' ],
    function (err, watch) {
        // If our user has not watched
        // a video recently, no record
        // is found.
        if (err || ! watch)
            return response.redirect('/');
        // Continue watching the video.
        response.redirect(`/video/${watch.video}?load=${watch.watchtime}`);
    });
}
//
function videoSave(request, response, next)
{
    const videoId = request.params.videoId,
          time    = request.body.time,
          user    = response.locals.user;
    // No record should be
    // kept for guests.
    if (! user)
        return next();
    // Store the playtime
    // in the Database.
    Watch.updateOne(
        { user: user._id },
        { video: videoId, watchtime: time },
        { upsert: true },
    function (err) {
        response.end();
    });
}
//
function videoCreate(request, response, next)
{
    const user  = response.locals.user;
    var   video = request.file;
    // This section should be carefully
    // reviewed, a guest can overwhelm
    // the system.
    if (! user)
    {
        if (video) fs.unlinkSync(video.path);
        return next();
    }
    // Given a calculated MD5 hash for
    // each video, duplicates will be
    // deleted.
    const record      = request.body,
          extension   = path.extname(video.originalname),
          destination = path.join('uploads', 'videos',
                                  video.md5 + extension),
          answers = new Array();
    fs.renameSync(video.path, destination);
    // A video contains nested Question
    // and Answer records, they have to
    // be constructed before being push
    // -ed to the Database.
    record.question  = [];
    record.video     = destination;
    record.user      = user._id;
	if (record.questionTime)
    for (i = 0; i < record.questionTime.length; i++)
    {
        // In an array of Questions, push an
        // Object holding its (Time, Text).
        record.question.push({
            questionTime: record.questionTime[i],
            questionText: record.questionText[i]
        });
        // Every Question has a predefined
        // CONSTANT number of Answers (4).
        for (j = 0; j < 4; j++)
            answers.push({
            answerText:  record.answerText[i * 4 + j],
            answerPoint: record.answerPoint[i * 4 + j]
        });
    }
    // Remove the original supplied
    // information from the request.
    delete record.questionTime;
    delete record.questionText;
    delete record.answerText;
    delete record.answerPoint;
    // Put the record in the Database,
    // forcing _id to be assigned to
    // nested Documents.
    video = new Video(record);
    video.save(async function (err, video) {
        if (err || !video)
            return next();
        // Update questionId for all Answers.
        (video.question).forEach((question, index) =>
        {
            answers[index * 4].questionId = question._id;
            answers[index * 4 + 1].questionId = question._id;
            answers[index * 4 + 2].questionId = question._id;
            answers[index * 4 + 3].questionId = question._id;
        });
        // Write back to the Database.
        video.answer = answers;
        await video.save();
        // Respond to the request with
        // Video information which can
        // subsequently be used.
        response.json({ id: video._id, title: video.title });
    });
}
//
function videoDelete(request, response, next)
{
    const user    = response.locals.user,
          videoId = request.body.videoId;
    //
    if ((! user) || (! videoId))
        return next();
    // Erase video document
    // from the Database.
    Video.deleteOne({
        _id:  videoId,
        user: user._id
    }).exec(async function (err, d) {
        if (err || !d.deletedCount)
            return next();
        // Remove related records
        // and return to Homepage.
        const filter    = new Object();
        filter['video'] = videoId;
        await Watch.deleteMany(filter);
        await Lesson.updateOne(filter, {video: null});
        response.redirect('/');
    });
}
//
function choiceGet(request, response)
{
    const questionId = request.params.questionId;
    //
    Choice
    .find(
        { question: questionId },
        'choiceText',
    function (err, choice) {
        //
        response
        .status(200)
        .json(choice);
    });
}
//
function createForm(request, response, next)
{
    // Render video creation form.
    response.render(path.join('video', 'create.ejs'));
}
//
function editForm(request, response, next)
{
    // Guests are not supposed
    // to be here.
    const videoId = request.query.videoId,
          user    = response.locals.user;
    if (! user)
        return next();
    //
    Video
    .findById(videoId)
    .exec(function (err, video) {
        // The Video should have been uploaded
        // by this person, reject if not.
        if (err || !video.user.equals(user._id))
            return next();
        // Proceed to render editing form.
        response.render(path.join('video', 'edit.ejs'), { video });
    });
}
//
function diffChoice(request, response, next)
{
    // Guest responses should not
    // be taken into account.
    const user = response.locals.user;
    if (! user)
        return next();
    // Gather request parameters
    // from URI. (/param?query=)
    const videoId    = request.params.videoId,
          questionId = request.params.questionId,
          choiceList = request.query.choice;
    var   choiceScore= 0;
    //
    Video
    .findById(videoId, 'question answer')
    .exec(async function (err, video) {
        //
        if (err || !video)
            return next();
        //
        i = (video.question).findIndex(q => (q._id).equals(questionId));
        j = (video.answer).slice(i * 4, (i + 1) * 4);
		j = j.filter((answer) => answer.answerText != ''); //
        k = Array.from(j.keys());
        // Filter out right responses (p)
        // from the wrong ones. (n)
        p = k.filter(k => j[k].answerPoint > 0);
        n = k.filter(k => ! p.includes(k)); 
        // Calculate and store the score.
        for (l = 0; l < choiceList.length && choiceList[l] < j.length; l++)
            choiceScore += j[choiceList[l]].answerPoint;
        let choice   = new Array();
        choice.user  = user._id;
        choice.score = choiceScore;
        choice.question = questionId;
        choice = new Choice(choice);
        // Return feedback to the client.
        await choice.save();
        response.json([p, n]);
    });
    //
}
//
module.exports =
{
    videoGetAll,
    videoGet,
    videoSave,
    videoCreate,
    videoLast,
    videoDelete,
    choiceGet,
    createForm,
    editForm,
    diffChoice
};