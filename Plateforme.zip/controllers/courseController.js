const fs     = require('fs'),
      path   = require('path'),
      Course = require('../models/course'),
      Lesson = require('../models/lesson'),
      Completion = require('../models/completion');
const { isValidObjectId } = require('mongoose');
//
async function lessonGetAll(courseId)
{
    var lessons = null;
    // Is this a correct MongoDB _id?
    if (! isValidObjectId(courseId))
        return lessons;
    // Find all lessons in a given
    // course. Extract four fields,
    // and sort results.
    lessons = await Lesson
              .find({ course: courseId }, '_id author title createdAt')
              .sort('field createdAt')
              .exec();
    return lessons;
}
//
async function courseIsAuthor(id, author)
{
    let courseDetail;
    // Ensure correctness of the _id.
    if (!id || !isValidObjectId(id))
        return false;
    // Match the Course.author on the
    // Database with the current user
    // _id.
    courseDetail = await Course.findById(id).exec();
    return courseDetail && (courseDetail.author).equals(author);
}
//
async function courseIsEnrolled(id, user)
{
    let courseDetail;
    courseDetail = await Course.findById(id).exec();
    return courseDetail && (courseDetail.participants).some((p) => p.equals(user));
}
//
function courseGetRaw(request, response, next)
{
    const courseId = request.params.courseId;
    Course
    .findById(courseId)
    .exec(async function (err, course) {
        if (err || !course)
            return next();
        // To alter an Object returned from
        // mongoose, duplicate its _doc and
        // operate on it.
        course = Object.assign({}, course._doc);
        course.lessons = await lessonGetAll(courseId);
        // Return a course and its
        // lessons as a JSON array.
        response
        .status(200)
        .json(course);
    });
}
//
function courseGet(request, response, next)
{
    const courseId = request.params.courseId;
    const user = response.locals.user;
    if (! user)
        return next();
    //
    Course.findById(courseId, async (err, course) =>
    {
        if (err || !course)
            return next();
        // Calculate the completed field to
        // see which lessons this user have
        // completed.
        var completed = [];
        var enrolled = false;
        if (user)
        {
            completed = await Completion.find({ user: user._id }, 'lesson');
            completed = completed.map(completion => completion.lesson);
            enrolled = await courseIsEnrolled(courseId, user._id);
        }
        // Get a Course and all its lessons.
        course = Object.assign({}, course._doc);
        course.lessons = await lessonGetAll(courseId);
        response.render(path.join('course', 'view.ejs'), { course, completed, enrolled });
    });
}
//
function courseForm(request, response, next)
{
    const user = response.locals.user;
    var course = new Array();
    if (! user) return next();
    // Initiate an empty Course
    // and render in the view.
    course.author = user._id;
    course = new Course(course);
    response.render(path.join('course', 'create.ejs'), { course });
}
//
function courseEditForm(request, response, next)
{
    const user = response.locals.user;
    const courseId = request.query.courseId;
    // A person is allowed to edit a
    // Courseif he/she is its author.
    Course.findOne({
        _id:    courseId,
        author: user._id
    }).exec(function (err, course) {
        if (err || !course)
            return next();
        //
        response.render(path.join('course', 'edit.ejs'), { course });
    });
}
//
function courseCheck(course)
{
    const attributes = Array(
        'title', 'category',
        'level', 'public'
    );
    // Make sure all the fields
    // have been filled and sent.
    return attributes.every((attribute) => {
        const  element = course[attribute];
        return element && element.length > 0;
    });
}
//
function courseCreate(request, response, next)
{
    const image  = request.file,
          user   = response.locals.user;
    var   course = request.body;
    // The user must be logged in, no
    // field should be missing for it
    // to proceed.
    // TODO:  Move authentication to a
    // middleware, prevent DoS attacks.
    if (! user || ! image || ! courseCheck(course)) {
        if (image)
            fs.unlinkSync(image.path);
        return next();
    }
    // Rename the file to its MD5 hash,
    // removing duplicates is automatic.
    const extension   = path.extname(image.originalname),
          destination = path.join('uploads', 'images',
                                  image.md5 + extension);
    fs.renameSync(image.path, destination);
    // Initialize course fields. 
    course.public = course.public != 'off';
    course.level  = parseInt(course.level);
    course.image  = destination;
    course.author = user._id;
	course.description = (course.description) ? course.description : ''; 
    // Create the course in memory,
    // and store it on the Database.
    course = new Course(course);
    course.save(function (err) {
        if (err)
            return next();
        // Send the user to the
        // course display page.
        response.redirect(`/view/${course._id}`);
    });
}
//
function courseEdit(request, response, next)
{
    const user = response.locals.user;
    const {
        _id,
        title,
        category,
        description,
        level,
        public
    } = request.body;
    // Guests are not allowed
    // to access this page.
    if (! user)
        return next();
    //
    Course
    .findById(_id)
    .exec(async function(err, course) {
        if (err || !course || !(course.author).equals(user._id))
            return next();
        // Update course fields
        // and save changes.
        course.title    = title;
        course.category = category;
        course.description = description;
        course.level  = level;
        course.public = (public != 'on') ? 0 : 1;
        await course.save();
        response.redirect(`/view/${course._id}`);
    });
}
//
function courseEnroll(request, response, next)
{
    const _id  = request.params.courseId,
          user = response.locals.user;
    if (! user)
        return next();
    // Put the current user in
    // the participants list.
    Course
    .updateOne(
        { _id },
        { $addToSet: { participants: user._id } }
    ).exec(function (err) {
        if (err)
            return next();
        response
        .status(200)
        .json({ message: 'Enrollment successful' });
    });
}
//
function courseSearch(request, response)
{
    var {
        term,
        limit
    } = request.body;
    //
    term = term.replace(/(?=\W)/g, '\\');
    if (limit >= 25)
        limit = 25;
    // Search a title with Regular
    // Expression to find similiar
    // ones.
    Course
    .find({ title: new RegExp(term, 'i'), public: 1 })
    .populate('author', '_id name')
    .limit(limit)
    .exec(function (err, courses) {
        response
        .status(200)
        .json(courses);
    });
}
//
module.exports = 
{
    lessonGetAll,
    courseIsAuthor,
    courseIsEnrolled,
    // courseGetAll,
    courseGetRaw,
    courseGet,
    courseForm,
    courseEditForm,
    courseCreate,
    courseEdit,
    courseEnroll,
    courseSearch
};