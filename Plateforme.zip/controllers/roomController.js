const ObjectId = require('mongoose').Types.ObjectId;
const Room = require('../models/room'),
      User = require('../models/user');
//
function roomCreate(request, response, next)
{
    const users  = Array(request.query.member).flat();
    //
    if (! users || ! users.every(id => ObjectId.isValid(id)))
    {
        next();
        return;
    }
    //
    Promise.all(users.map(_id => User.countDocuments({
        _id
    }))).then(function (result)
    {
        let sum = eval(result.join('+'));
        //
        if (sum < users.length)
        {
            next();
            return;
        }
        //
        response
        .status(200)
        .json(users);
    });
    //
}
//
function roomGet(request, response)
{
    // roomId
}
//
module.exports =
{
    roomCreate,
    roomGet
};