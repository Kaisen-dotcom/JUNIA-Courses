const { isValidObjectId } = require('mongoose');
const path = require('path'),
      Lesson = require('../models/lesson'),
      courseController = require('../controllers/courseController');
const Video = require('../models/video');
const Watch = require('../models/watch');
const Course = require('../models/course');
const Completion = require('../models/completion');
//
function lessonGet(request, response, next) {
    const user = response.locals.user;
    const lessonId = request.params.lessonId;
    if (! user)
        return next();
    //
    Lesson.findById(lessonId, async (err, lesson) => {
        if (err || (! lesson))
            return response.end();
        //
        const enrolled = await courseController.courseIsEnrolled(lesson.course, user._id);
        const owner = (lesson.author).equals(user._id);
        if (! enrolled && ! owner) return next();
        //
        const completed = await Completion.countDocuments({
            user:   user._id,
            lesson: lessonId
        });
        response.render(path.join('lesson', 'view.ejs'), { lesson, completed, enrolled });
    });
}
//
async function lessonComplete(request, response, next)
{
    const user = response.locals.user;
    const lessonId = request.params.lessonId;
    //
    if (! user)
        return next();
    //
    Lesson
    .findById(lessonId, async function (err, lesson) {
        if (err || (! lesson))
            return next();
        //
        const course = await Course.findById(lesson.course);
        console.log(course.participants);
        //
        if ((course.participants).includes(user._id))
        {
            //
            await (new Completion({
                user: user._id,
                lesson: lessonId
            }))
            .save()
            .catch((e) => console.log(e));
        }
        //
        return response.redirect(`/view/${lesson.course}`);
    });
}
//
async function lessonForm(request, response, next)
{
    const user = response.locals.user;
    if (! user)
        return next();
    //
    response.render(path.join('lesson', 'create.ejs'), {
        lesson: new Lesson()
    });
}
//
function lessonEditForm(request, response, next)
{
    const user = response.locals.user;
    const lessonId = request.query.lessonId;
    //
    if ((! user) || (! isValidObjectId(lessonId)))
        return next();
    //
    Lesson.findOne({
        _id:    lessonId,
        author: user._id
    }).exec(function (err, lesson)
    {
        if (err || (! lesson))
            return next();
        //
        response.render(path.join('lesson', 'edit.ejs'), { lesson });
    });
}
//
function lessonEdit(request, response, next)
{
    const user = response.locals.user;
    const {
        _id,
        title,
        video,
        markdown,
    } = request.body;
    //
    if (! user)
        return next();
    // TODO: make sure this person is the author
    Lesson
    .findById(_id)
    .exec(async function (err, lesson) {
        if (err || (! lesson) || !(lesson.author).equals(user._id))
            return next();
        //
        lesson['title']    = title;
        if (video) lesson['video'] = video;
        lesson['markdown'] = markdown;
        await lesson.save();
        response.redirect(`/lesson/${_id}`);
    });
}
//
async function lessonCreate(request, response, next)
{
    const courseId = request.query.courseId;
    const user     = response.locals.user;
    var   lesson   = request.body;
    const isAuthor = await courseController.courseIsAuthor(courseId, user._id);
    //
    if (! isAuthor)
    {
        next();
        return;
    }
    //
    lesson.author = user._id;
    lesson.course = courseId;
    if (! lesson.video)
        delete lesson.video;
    lesson = new Lesson(lesson);
    //
    lesson.save((err, lesson) => {
        if (err)
        {
            console.log(err);
            next();
            return;
        }
        response.redirect(`/lesson/${lesson._id}`);
    });
}
//
function lessonDelete(request, response, next)
{
    const user = response.locals.user;
    const lessonId = request.body.lessonId;
    //
    if ((! user) || (! lessonId))
        return next();
    //
    Lesson.findOneAndDelete({
        _id:    lessonId,
        author: user._id
        },
    async function (err, lesson) {
        //
        if (err || (! lesson))
            return next();
        //
        await Video.deleteOne({ _id: lesson.video });
        await Watch.deleteMany({ video: lesson.video });
        return next();
    });
}
//
module.exports =
{
    lessonComplete,
    lessonGet,
    lessonEditForm,
    lessonEdit,
    lessonForm,
    lessonCreate,
    lessonDelete
};