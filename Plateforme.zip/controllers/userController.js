const path = require('path'),
      jwt  = require('jsonwebtoken'),
      User = require('../models/user'),
      Notification = require('../models/notification');
require('dotenv').config();
//
function userDashboard(request, response)
{
    // Verify logged in
    response
    .status(200)
    .send('Dashboard');
}
//
async function userGet(email)
{
    //
    return await User.findOne({
        email
    });
}
//
async function userDetailAll()
{
    const userInfo = await User
    .aggregate(Array({
        $lookup: {
            'from': 'courses',
            'localField': '_id',
            'foreignField': 'participants',
            'as': 'courses'
    }}, {
        $project: {
            'name': true,
            'birth': true,
            'following': true,
            'courses._id': true,
            'courses.image': true
    }}));
    //
    return userInfo;
}
//
async function userProfile(request, response, next)
{
    var   userId = request.params.userId;
    var userInfo = await userDetailAll(); 
    userInfo     = userInfo.find((user) => user._id.equals(userId));
    //
    response.render(path.join('user', 'view.ejs') , { profile: userInfo });
}
//
function userNotification(request, response, next)
{
    response.render('video.ejs');
    /*
    const user = response.locals.user,
          destination = user._id;
    //
    if (! user)
    {
        next();
        return;
    }
    //
    Notification
    .find({ destination })
    .exec(function (err, notifications) {
        if (err)
        {
            next();
            return;
        }
        //
        response
        .status(200)
        .json(notifications);
    });
    */
}
//
function userLogin(request, response)
{
    const {
        email,
        password
    } = request.body;
    //
    (User.findOne({
        email
    })).exec(function (err, user) {
        if (err || !user || user.password != password)
            return response
            .status(401)
            .send('Login failed');
        //
        response
        .cookie('token', jwt.sign({ email }, process.env.SECRET_KEY, { expiresIn: 3600 * 1000 }), {
            httpOnly: true,
            // secure: true,
            maxAge: 3600 * 1000 // Remain connected for a maximum of 1-hour.
        })
        .redirect(302, '/');
    });
}
//
function userLogout(_, response) {
    response
    .clearCookie('token')
    .redirect('/');
}
//
function userForm(_, response) {
    response.render(path.join('user', 'create.ejs'));
}
//
function userCheck(user)
{
    const attributes = Array(
        'name', 'email',
        'birth', 'password'
    );
    //
    return attributes.every((attribute) => {
        const  element = user[attribute];
        return element && element.length > 0;
    });
}
//
function userCreate(request, response, next)
{
    var user = response.locals.user;
    // Are the supplied fields correct and
    // enough for user-creation?
    if ((! user) || (! userCheck((user = request.body))))
        return next();
    // Create the user and store it
    // in the Database.
    user.birth = new Date(user.birth);
    user = new User(user);
    user.save(function (err, user) {
        if (err || !user)
            return next();
        // Redirect to its profile.
        response.redirect(`/profile/${user._id}`);
    });
}
//
module.exports =
{
    userDashboard,
    userGet,
    userProfile,
    userNotification,
    userLogin,
    userLogout,
    userForm,
    userCreate
};